1. For edit/view: vim ls_com.txt
For view: cat ls_com.txt
2. ls -h -l ~ > ls_out.txt
3. gcc -Wall -std=c99 hello.c -o hello
4. ./hello
5. tar cvf submit.tar ls_com.txt ls_out.txt hello.c readme.txt