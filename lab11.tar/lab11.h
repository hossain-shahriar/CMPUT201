#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

struct graph_node {
    int num; //the label of the node in the graph
    struct graph_node *next; // pointer to next node; NULL if there is no next node
};

struct bst_node {
    char *key; //the string stored in the BST node - storage MUST be dynamically allocated
    struct bst_node *left; // pointer to left child; NULL if there is no left child.
    struct bst_node *right; // pointer to right child; NULL if there is no right child.
};


// Insert your function declarations for ex11q1.c below:
struct graph_node **initialize(int n);
void create_AL(struct graph_node **list, int n, int edges[][2], int m);
bool find(struct graph_node **list, int edge[2]);
void add(struct graph_node **list, int edge[2]);
void delete(struct graph_node **list, int edge[2]);
void destroy_AL(struct graph_node **list, int n);
// end of insertion


// Insert your function declarations for ex11q2.c below:
struct bst_node *create_BST(char *string);
bool validate_BST(struct bst_node *root);
void insert_node(char *string, struct bst_node *root);
struct bst_node *find_max(struct bst_node *root);
struct bst_node *find_min(struct bst_node *root);
struct bst_node *delete_node(char *string, struct bst_node *root);
// end of insertion

void check_create(void);
void check_validate(struct bst_node *root);
void check_insert(struct bst_node *root);
void check_find_max(struct bst_node *root);
void check_find_min(struct bst_node *root);
void check_delete_node(struct bst_node *root);
