/* Purpose: Binary Search Tree
 * Author: Mohammad Shahriar Hossain
 * Date: 18 November, 2022
 * References: https://www.geeksforgeeks.org/binary-search-tree-set-1-search-and-insertion/
 * https://www.geeksforgeeks.org/a-program-to-check-if-a-binary-tree-is-bst-or-not/
 * https://www.geeksforgeeks.org/find-the-node-with-maximum-value-in-a-binary-search-tree/
 * https://www.geeksforgeeks.org/find-the-minimum-element-in-a-binary-search-tree/
 * https://www.geeksforgeeks.org/deletion-in-binary-search-tree/
 */

#include "lab11.h"

// *** BST property ***
// 1) The left subtree of a node must only contain nodes with keys
// 	    that come before the parent in alphabetical order.
// 2) The right subtree of a node must only contain nodes with keys
// 		that come after the parent in alphabetical order.
// 3) Every subtree is also a BST.
// 4) You may assume all nodes have different keys.


// The following function creates a BST by initializing a root node with the specified string.
// 1) Parameters: 
//      char *string: The string to be copied to the root node.
// 2) Returns a pointer to the root node.
// 3) The key of the node MUST be malloc-ed.
// 4) Set left and right to NULL, indicating there's no left or right child at the start.
struct bst_node *create_BST(char *string) {
    struct bst_node *temp = (struct bst_node *)malloc(sizeof(struct bst_node));
    char *key = (char *)malloc((strlen(string) + 1) * sizeof(char));
    strcpy(key, string);
    temp->key = key;
    temp->right = NULL;
    temp->left = NULL;
    return temp;
}


// The following function inserts a node with the specified string into the proper position of the BST.
// 1) Parameters: 
//      char *string: The string to be copied to the new node
//      struct bst_node *root: A pointer to the root node of the BST
// 2) The new node should be inserted as a LEAF NODE of the tree.
//      After insertion, the BST property should be maintained.
//      You can find the definition of the BST property at the top of this file.
// 3) The key of the node MUST be malloc-ed.
void insert_node(char *string, struct bst_node *root) {
    struct bst_node *node = create_BST(string);

    if (root == NULL)
    {
        root = create_BST(string);
    }

    struct bst_node *prev = NULL;

    while (root != NULL)
    {
        if (strcmp(root->key, string) < 0)
        {
            prev = root;
            root = root->right;
        }
        else if (strcmp(root->key, string) > 0)
        {
            prev = root;
            root = root->left;
        }
    }
    if (strcmp(prev->key, string) < 0)
    {
        prev->right = node;
    }
    else
    {
        prev->left = node;
    }
}


// The following function validates a BST.
// 1) Parameters:
//      struct bst_node *root: A pointer to the root node of the BST
// 2) Returns true if the tree rooted at `root` is a BST; false otherwise
//      Returns true if there's <= 1 node in the tree.
// 3) You can find the definition of a BST at the top of this file.
bool validate_BST(struct bst_node *root) {
    if (root == NULL)
    {
        return true;
    }
    if (root->left == NULL && root->right == NULL)
    {
        return true;
    }
    struct bst_node *max = find_max(root->left);
    struct bst_node *min = find_min(root->right);

    if (root->left != NULL && strcmp(max->key, root->key) < 0)
    {
        return true;
    }
    if (root->right != NULL && strcmp(min->key, root->key) < 0)
    {
        return false;
    }
    if (!validate_BST(root->left) || !validate_BST(root->right))
    {
        return false;
    }
    return true;
}


// The following function finds the node with the maximum key in the BST.
// 1) Parameters:
//      struct bst_node *root: A pointer to the root node of the BST
// 2) Returns a pointer to the node with the maximum key in the BST rooted at `root`.
struct bst_node *find_max(struct bst_node *root) {
    struct bst_node *current = root;

    while (current->right != NULL)
    {
        current = current->right;
    }
    return current;
}


// The following function finds the node with the minimum key in the BST.
// 1) Parameters:
//      struct bst_node *root: A pointer to the root node of the BST
// 2) Returns a pointer to the node with the minimum key in the BST rooted at `root`.
struct bst_node *find_min(struct bst_node *root) {
    struct bst_node *current = root;

    while (current->left != NULL)
    {
        current = current->left;
    }
    return current;
}


// The following function deletes the node with the specified string from the BST if it exists.  
// 1) Parameters:
//      char *string: The string to be deleted
//      struct bst_node *root: A pointer to the root node of the BST
// 2) Returns a pointer to the (new) root node of the BST.
//      Returns NULL if the tree if empty after deletion.
// 3) The BST property must be maintained after deletion.
// 4) You may use the above functions directly if needed.
struct bst_node *delete_node(char *string, struct bst_node *root) {
    if (root == NULL)
        return NULL;
    if (strcmp(string, root->key) > 0)
        root->right = delete_node(string, root->right);
    else if (strcmp(string, root->key) < 0)
        root->left = delete_node(string, root->left);

    else
    {
        // node with only one child or no child
        if (root->left == NULL)
        {
            struct bst_node *temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL)
        {
            struct bst_node *temp = root->left;
            free(root);
            return temp;
        }

        // node with two children:
        struct bst_node *temp = find_min(root->right);

        root->key = temp->key;
        root->right = delete_node(temp->key, root->right);
    }
    return root;
}
