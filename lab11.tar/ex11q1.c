/* Purpose: Adjacency List Representation
 * Author: Mohammad Shahriar Hossain
 * Date: 18 November, 2022
 * References:
 */

#include "lab11.h"

// The following function initialize a pointer array, each of which points to a graph_node
// Parameter n is the number of the nodes in the graph
// Returns a pointer to the first element in the pointer array.
// 1) the nodes in the graph are labelled from 0 to n-1;
// 2) since no edges exist yet, the pointers `next` should all point to NULL.
struct graph_node **initialize(int n) {
    struct graph_node *adj[n];
    for (int i = 0; i < n; i++)
    {
        // adj[i] = malloc(sizeof(struct graph_node));

        adj[i] = NULL;
    }
    struct graph_node **head = adj;
    return head;
}   


// The following function uses the pointer returned by `initialize()` to create the adjacency list.
// Parameters:
//   `list` points to the first element in the pointer array representing adjacency list
//   `n` is the number of the nodes in the graph
//   `edges[][2]` is an array of edges
//   `m` is the number of edges
// 1) The nodes in an adjacency list should be ordered by increasing node labels
void create_AL(struct graph_node **list, int n, int edges[][2], int m) {
    scanf("%d", &n);
    scanf("%d", &m);
    list = initialize(n);
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            scanf("%d", &edges[i][j]);
        }
    }

    for (int k = 0; k < m; k++)
    {
        struct graph_node *temp = (struct graph_node *)malloc(sizeof(struct graph_node));
        temp = edges[k][0];
        // if (list[node1] != NULL)
        while (temp->next != NULL)
        {
            temp = temp->next;
        }

        // if (list[node1]->next == )
        // {
        //     /* code */
        // }
    }
}


// The following function finds whether or not a given edge is inside the graph.
// Parameters:
//   `list` points to the first element in the pointer array representing adjacency list
//   `edge[2]` is an edge connecting two nodes whose labels are the elements of `edge`
// 1) Return true if and only if the given edge is inside the graph.
bool find(struct graph_node **list, int edge[2]) {
    
}


// The following function adds a given edge to the graph.
// Parameters:
//   `list` points to the first element in the pointer array representing adjacency list
//   `edge[2]` is an edge connecting two nodes whose labels are the elements of `edge`
// 1) If the given edge is inside already, then do nothing;
// 2) otherwise adds it in so that `list` is updated to represent the adjacency list.
void add(struct graph_node **list, int edge[2]) {

}


// The following function deletes a given edge from the graph.
// Parameters:
//   `list` points to the first element in the pointer array representing adjacency list
//   `edge[2]` is an edge connecting two nodes whose labels are the elements of `edge`
// 1) If the given edge isn't inside already, then do nothing;
// 2) otherwise deletes it so that `list` is updated to represent the adjacency list.
void delete(struct graph_node **list, int edge[2]) {

}


// The following function deallocate the adjacency list.
// Parameters:
//   `list` points to the first element in the pointer array representing adjacency list
//   `n` is the number of the nodes in the graph
// 1) there should be no memory leaks after this function returns.
void destroy_AL(struct graph_node **list, int n) {

}
