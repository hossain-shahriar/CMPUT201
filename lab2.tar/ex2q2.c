/* Purpose: Determining the number of each denomination
 * Author: Mohammad Shahriar Hossain
 * Date: 13 September, 2022
 * Persons discussed w/:
 * References: https://youtu.be/_i2faEmp2lo
 */

#include <stdio.h>

int main()
{
	int amount, bills;

	int denom[5] = {100, 20, 10, 2, 1}; //Making an array of the denominations
	printf("Enter a dollar amount: ");
	
	if (scanf("%d", &amount) && amount >= 0) //Here scanf has a return value. It will return 1 and 0 if the inputs are integer and non integer respectively. Also the input has to be a positive number
	{
		scanf("%*[^\n]"); //Scanning past any invalid input
		for (int i = 0; i < 5; i++)
		{
			bills = amount / denom[i];
			if (denom[i] == 1)
			{
				printf("Loonies: %d\n", bills);
			}
			else if (denom[i] == 2)
			{
				printf("Toonies: %d\n", bills);
			}
			else
			{
				printf("$%d bills: %d\n", denom[i], bills);
			}
			amount = amount - denom[i] * bills;
		}
	}
	else
	{
		printf("Input is not valid.\n");
	}
	return 0;
}
