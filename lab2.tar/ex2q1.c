#include <stdio.h>

int main()
{// This program adds two numbers together
	int operand1, operand2, result;
	operand1 = 1;
	operand2 = 2;
	result = operand1 + operand2;
	printf("The result is: %d\n", result);
	printf("The result times ten is: %d\n", result*10);
}
