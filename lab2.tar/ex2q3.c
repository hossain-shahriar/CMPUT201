/* Purpose: Determining discounts on books
 * Author: Mohammad Shahriar Hossain
 * Date: 13 September, 2022
 * Persons discussed w/:
 * References: https://youtu.be/_i2faEmp2lo
 */

#include <stdio.h>

int main()
{
	float num, subtotal;

	printf("How many books are you purchasing: ");
	if (scanf("%f", &num) && (int)num >= 0) //Here scanf has a return value. It will return 1 and 0 if the inputs are integer and non integer respectively. Also the input has to be a positive number
	{
		scanf("%*[^\n]"); //Scanning past any invalid input
		printf("What is your subtotal in dollars: ");
		if (scanf("%f", &subtotal) && (int)subtotal >= 0) //Here scanf has a return value. It will return 1 and 0 if the inputs are integer and non integer respectively. Also the input has to be a positive number
		{
			scanf("%*[^\n]"); //Scanning past any invalid input

			//Discount depending on subtotals
			if ((int)subtotal >= 30 && (int)subtotal < 60)
			{
				subtotal -= 5;
			}
			else if ((int)subtotal >= 60 && (int)subtotal < 90)
			{
				subtotal -= 10;
			}
			else if ((int)subtotal >= 90 && (int)subtotal < 110)
			{
				subtotal -= 20;
			}
			else
			{
				subtotal -= 25;
			}
			printf("Your total after applying the coupon is: $%0.2f\n", subtotal);

			//Discount depending on number of books
			if ((int)num == 1)
			{
				subtotal = subtotal - subtotal * 0.00;
			}
			else if ((int)num == 2)
			{
				subtotal = subtotal - subtotal * 0.20;
			}    
			else if ((int)num == 3)
			{
				subtotal = subtotal - subtotal * 0.30;
			}
			else
			{
				subtotal = subtotal - subtotal * 0.40;
			}
			printf("Your total after applying the percentage discount is: $%0.2f\n", subtotal);
		}
		else
		{
			printf("Subtotal is not valid.\n");
		}
	}
	else
	{
		printf("Number of books is not valid.\n");
	}

	return 0;
}
