/* Purpose: Dice Game
 * Author: Mohammad Shahriar Hossain
 * Date: 22 September, 2022
 * Persons discussed w/:
 * References:
 */

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main()
{
    int i = 0, turn_total, total[2] = {0, 0}, flag, random;
    char input;
    srand(time(NULL));

    while (total[0] < 100 && total[1] < 100)
    {
        i = i % 2;      // to flip player turn by turn. i will either be 0 or 1
        flag = 0;       // to determine if the player has chosen 'q' or got 1 in dice
        turn_total = 0; // total score of players in each turn
        printf("Player %d's turn. Your point score is %d\n", i, total[i]);

        while (flag == 0)
        {
            printf("Enter 'r' to roll, or 'q' to end your turn: ");
            if (scanf(" %c", &input) != 1) // for invalid input (if the input is an int or float)
            {
                return 1;
            }
            if (input == 'q')
            {
                flag = 1;
            }
            else if (input == 'r')
            {
                random = (rand() % 6) + 1; // generating random number between 1 to 6
                if (random == 1)
                {
                    turn_total = 0; // no turn score will be added if the player gets 1 in dice
                    printf("You rolled a %d. Your turn total is %d.\n", random, turn_total);
                    flag = 2;
                }
                else
                {
                    turn_total += random;
                    printf("You rolled a %d. Your turn total is %d.\n", random, turn_total);
                }
            }
            else // if the input is any other character than 'r' or 'q'
            {
                return 1;
            }
            if (flag == 1)
            {
                total[i] = total[i] + turn_total; // adding the turn total to the total score as the player has successfully ended the turn without getting 1 in dice
                printf("Turn ended. Player %d's point score is now %d.\n", i, total[i]);
            }
            else if (flag == 2)
            {
                printf("Turn ended. Player %d's point score is now %d.\n", i, total[i]); // not adding the turn total as the player got 1 in dice
            }
        }
        i += 1;
    }
    if (total[0] >= 100) // determining who crossed 100 points
    {
        printf("Player 0 wins, with %d points!", total[0]);
    }
    else
    {
        printf("Player 1 wins, with %d points!", total[1]);
    }

    return 0;
}
