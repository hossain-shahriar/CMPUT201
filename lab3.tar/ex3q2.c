/* Purpose: Range of a Dataset
 * Author: Mohammad Shahriar Hossain
 * Date: 22 September, 2022
 * Persons discussed w/:
 * References:
 */

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num[20], max, min, range; // declaring max, min and range
    printf("Enter 20 integers: ");

    for (int i = 0; i < 20; i++) // loop runs 20 times
    {
        if (scanf("%d", &num[i]) != 1) // checking the input validity
            return 1;
    }

    max = num[0]; // setting the first number to be the max
    min = num[0]; // setting the first number to be the min

    for (int i = 1; i < 20; i++)
    {
        if (num[i] > max)
        {
            max = num[i]; // if num in that index is greater than the previous max then change it to the current num
        }
        if (num[i] < min)
        {
            min = num[i]; // if num in that index is less than the previous min then change it to the current num
        }
    }

    range = max - min; // calculating range
    printf("The range of these 20 integers is: %d\n", range);

    return 0;
}
