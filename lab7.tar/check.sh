#!/usr/bin/bash
# Check script given for lab 7. The following is checked:
# - The tar has all required files
# - All 3 programs compile without warnings
# - Runs programs on the cases presented in the lab description
#
# Written in Fall 2022 for CMPUT 201 @ University of Alberta
# by Akemi Izuko <akemi.izuko@ualberta.ca>
umask 077
shopt -s lastpipe

declare -r TMP_DIR="$(mktemp -d --tmpdir=/dev/shm)"  # Shared mem is big enough?
declare -r REQUIRED_FILES=(\
  ex7q1.c
  lab07.h
  lab07.o
  check.sh
)

print_help() {
  cat <<HELP
Check file for lab 7

USAGE:
    $0 submit.tar
    bash $0 submit.tar
HELP
}

assert_lab_machine() {
  if [[ "$(hostname)" =~ ^ug[0-9]{2}$ || "$(hostname)" == ohaton ]]; then
    return 0
  else
    return 1
  fi
}

if ! [[ -r "$1" ]]; then
  print_help
  exit 1
elif ! assert_lab_machine; then
    echo " \`$(hostname) \` is not a lab machine!"
    echo "Please scp your files to a lab machine and run this check script there"
    exit 1
else
  # Untar file
  if ! tar -C "$TMP_DIR" -xf "$1"; then
    echo "Something is wrong with the tar file \"${1}\""
    exit 1
  fi

  # Check to make sure all files are present
  for file in "${REQUIRED_FILES[@]}"; do
    if ! [[ -e "${TMP_DIR}/${file}" ]]; then
      echo "You're missing \"${file}\" in your submission"
      exit 1
    fi
  done

  # Compile and check the only part
  declare -i return_val=0

  if ! gcc -Wall -std=c99 "${TMP_DIR}/ex7q1.c" "${TMP_DIR}/lab07.o" -o "${TMP_DIR}/ex7q1"
  then
    echo "ex7q1.c compiled with errors!"
    echo "Programs must compile without errors for full marks"
    return_val=1
  fi

  # Checks for heap memory leaks
  declare -i valgrind_out=0

  if ! valgrind "${TMP_DIR}/ex7q1" 2> "${TMP_DIR}/valgrind_out"; then
    echo ""
    echo "Failed to pass all tests"
    return_val=1
  else
    echo ""
  fi

  awk 'match($0, /in use at exit/) {
    split($0, a, " ");
    printf "%d", a[6];
  }' "${TMP_DIR}/valgrind_out" | read -r valgrind_out

  if [[ "$valgrind_out" -ne 0 ]]; then
    cat <<LEAKED
Memory leaks detected!
Marks will be taken off for memory leaks
Leaked $valgrind_out bytes
LEAKED
    return_val=1
  else
    echo "No memory leaked! Perfect stuff"
  fi

  if [[ $return_val -eq 0 ]]; then
    echo "All checks passed!"
    echo "If you feel you've tested enough, you can submit. Good luck!"
  fi

  rm -rf "${TMP_DIR}"
  exit $return_val
fi
