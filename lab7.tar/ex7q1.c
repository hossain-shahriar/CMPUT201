/* Purpose: Hash table functions
 * Author: Mohammad Shahriar Hossain
 * Date: 27 October, 2022
 * References:
 */
#include "lab07.h"

int main() {
    // Create your array of pointers to integer arrays (ht) of length HT_SIZE (= 29) here. This will be your hash table.
    int *ht[HT_SIZE]; // Add code below to create `ht`:
    for (int i = 0; i < HT_SIZE; i++)
    {
        ht[i] = (int *)calloc(2, sizeof(int)); // creating ht, dynamically allocating 2*sizeof(int) in every pointer
    }


    // Do not change anything below:
    test(ht);
    return 0;
}


// This function hashes `input` according to the following formula:
//  h(t) = t mod value
// Arguments:
// - input: a pointer to the input integer to be hashed
// - output: a pointer to the output integer to store the hashed value in
// - value: used in the formula above
void hash_el(int *input, int *output, int value) {
    *output = *input % value; // hashing the value
}


// This function inserts an element into the hash table.
// 1) First, hash the value of `x` using `hash_el` to get `z = h(x)`
// 2) Then, if the array pointed to `ht[z]` is empty (element `[0]` = 0), insert `x` into element `[1]`
//    in the array at `ht[z]`, and increase the element counter in element `[0]`
// 3) If the array pointed to by `ht[z]` is not empty
//    (e.g. element `[0]` != 0), you will have to reallocate more size in the array.
// Arguments:
// - ht: an array of pointers to integer arrays, where values will be stored
// - x: a pointer to an integer x, where x is the value to be inserted into ht
void insert_el(int *ht[], int *x) {
    int z; // the value from hashing will be stored here
    hash_el(x, &z, HT_SIZE);
    if (ht[z][0] == 0) // if there is no element
    {
        ht[z][1] = *x;
        ht[z][0] += 1;
    }
    else // if there is atleast one element present
    {
        ht[z][0] += 1;
        ht[z] = realloc(ht[z], (ht[z][0] + 1) * sizeof(int)); // increasing the size by 1 sizeof(int)
        ht[z][ht[z][0]] = *x; // inserting the value at the last index
    }
}


// This function deletes an element from the hash table.
// 1) First, hash the value of `x` using `hash_el` to get `z = h(x)`
// 2) Then, if the array pointed to `ht[z]` is empty (element `[0]` = 0), do nothing
// 3) If the array pointed to by `ht[z]` is not empty and `x` is inside
//    (e.g. element `[0]` != 0 after the update), you will have to reallocate less size in the array.
// Arguments:
// - ht: an array of pointers to integer arrays, where values will be stored
// - x: a pointer to an integer x, where x is the value to be deleted from ht
void delete_el(int *ht[], int *x) {
    int z; // the value from hashing will be stored here
    hash_el(x, &z, HT_SIZE);
    int flag = 0; // to determine if the element is found
    if (ht[z][0] > 0) // if there is atleast one element
    {
        for (int i = 1; i < ht[z][0]; i++)
        {
            if (ht[z][i] == *x) // if found
            {
                flag = 1;
            }
            if (flag == 1)
            {
                ht[z][i] = ht[z][i + 1]; // deleting the element by pushing the next value into the position
            }
        }
        if (ht[z][ht[z][0]] == *x) // if the element is at last index
        {
            flag = 1;
            ht[z][ht[z][0]] = 0;
        }
        if (flag == 1 && ht[z][0] == 1) // if there is only one element then we can just delete the element but cannot reduce the size of the array, therefore not reallocating here
        {
            ht[z][0] = 0;
            ht[z][1] = 0;
        }
        if (flag == 1 && ht[z][0] > 1) // if there is more than one element
        {
            ht[z][0] -= 1;
            ht[z] = realloc(ht[z], (ht[z][0] + 1) * sizeof(int)); // decreasing the size by 1 sizeof(int)
        }
    }
}


// This function searches for an element in the hash table.
// 1) First, hash the value of `x` using `hash_el` to get `z = h(x)`
// 2) Then, make the value of `hash` to be `z`, and search for the position of `x` in the table
// 3) Make the value of `pos` to be the index of `x` in the array pointed to by `ht[z]`
// Arguments:
// - ht: an array of pointers to integer arrays, where values will be stored
// - x: a pointer to an integer x, where x is the value to be searched for
void search_el(int *ht[], int *x, int *hash, int *pos) {
    hash_el(x, hash, HT_SIZE);
    if (ht[*hash][0] > 0) // if the array is not empty
    {
        for (int i = 1; i < ht[*hash][0] + 1; i++)
        {
            if (ht[*hash][i] == *x) // if found
            {
                *pos = i;
            }
        }
    }
}


// Frees the memory allocated in the hash table
// 1) For every call of `malloc` or `calloc` to allocate memory, there should be a corresponding call of `free` to free it
// 2) Do not free the array of pointers to integer arrays, just free the arrays malloc-ed or calloc-ed.
// 3) You can use `valgrind` to check for memory leaks (aka missed frees) in your program
void free_ht(int *ht[]) {
    for (int i = 0; i < HT_SIZE; i++)
    {
        free(ht[i]); // freeing dynamically allocated memory one by one
    }
}
