#include <stdio.h>
#include <stdlib.h>

#define HT_SIZE 29

void hash_el(int *input, int *output, int value);
void insert_el(int *ht[], int *x);
void delete_el(int *ht[], int *x);
void search_el(int *ht[], int *x, int *hash, int *pos);
void free_ht(int *ht[]);

// Testing functions
void test(int *ht[]);
void test_hash_el(void);
void test_insert_el(int *ht[]);
void test_delete_el(int *ht[]);
void test_search_el(int *ht[]);
