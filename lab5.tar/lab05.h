#include <stdio.h>
#include <stdbool.h>

int test1a(int (*prod)(int a[], int b[], int n));
int test2a(int (*proc)(int n, int matrix[n][n], int xmin, int xmax, int ymin, int ymax));

int recursiveProduct(int a[], int b[], int n);
int process(int n, int matrix[n][n], int xmin, int xmax, int ymin, int ymax);
