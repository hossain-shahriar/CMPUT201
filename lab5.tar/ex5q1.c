/* Purpose: Product finder
 * Author: Mohammad Shahriar Hossain
 * Date: October 6, 2022
 * References:
 */

#include "lab05.h"

// Do not touch anything in this main function (used for testing purposes)
int main() {
    return test1a(recursiveProduct);
}

// The following function calculates the product defined in lab05.
// n is the maximum index of the arrays (for an array of length 7, n = 6)
// Complete the function definition:
// a) Must be recursive.
int recursiveProduct(int a[], int b[], int n) {
    if (n == 0)
    {
        return a[n] + b[n];
    }
    else
    {
        return (a[n] + b[n]) * recursiveProduct(a, b, n - 1);
    }
}

