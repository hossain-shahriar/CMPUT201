/* Purpose: Processing 2d array
 * Author: Mohammad Shahriar Hossain
 * Date: October 6, 2022
 * References:
 */

#include "lab05.h"

// Do not touch anything in this main function (used for testing purposes)
int main() {
    return test2a(process);
}

// This function is a recursive function that processes a 2d array like in the lab05 description.
// The values xmin and xmax, ymin and ymax define the "four corners" of the array indexes that are
// currently being processed. For example, we start with xmin = 0, xmax = n-1, ymin = 0, ymax = n-1
// to indicate that we are processing the entire array at the start.
// Complete the function definition:
int process(int n, int matrix[n][n], int xmin, int xmax, int ymin, int ymax) {
    while (xmin != xmax && ymin != ymax)
    {
        int max = matrix[xmin][ymin];
        for (int i = xmin; i <= xmax; i++)
        {
            for (int j = ymin; j <= ymax; j++)
            {
                if (i == xmin || i == xmax || j == ymin || j == ymax)
                {
                    if (matrix[i][j] > max)
                    {
                        max = matrix[i][j];
                    }
                }
            }
        }
        for (int i = xmin; i <= xmax; i++)
        {
            for (int j = ymin; j <= ymax; j++)
            {
                if (i == xmin || i == xmax || j == ymin || j == ymax)
                {
                    if (matrix[i][j] == max)
                    {
                        if (i == xmin)
                        {
                            return max + process(n, matrix, xmin + 1, xmax, ymin, ymax);
                        }
                        else if (j == ymax)
                        {
                            return max + process(n, matrix, xmin, xmax, ymin, ymax - 1);
                        }
                        else if (i == xmax)
                        {
                            return max + process(n, matrix, xmin, xmax - 1, ymin, ymax);
                        }
                        else if (j == ymin)
                        {
                            return max + process(n, matrix, xmin, xmax, ymin + 1, ymax);
                        }
                    }
                }
            }
        }
    }
    int sum = matrix[xmin][ymin];
    if (xmin == xmax)
    {
        for (int i = ymin + 1; i <= ymax; i++)
        {
            sum = sum + matrix[xmin][i];
        }
    }
    else
    {
        for (int i = xmin + 1; i <= xmax; i++)
        {
            sum = sum + matrix[i][ymin];
        }
    }
    return sum;
}
