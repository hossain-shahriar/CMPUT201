/* Purpose: Quaternary heap functions
 * Author: Mohammad Shahriar Hossain
 * Date: 27 October, 2022
 * References: https://www.geeksforgeeks.org/heap-sort-for-decreasing-order-using-min-heap/
 */

#include "lab08.h"

// Swaps the elements pointed to by el1 and el2.
void swap(int *el1, int *el2) {
    int temp = *el1;
    *el1 = *el2;
    *el2 = temp;
}

// Returns a pointer to the parent node given the pointer to a child node
//     and a pointer to the first element in the heap.
// If child points to the first element in the array, return a null pointer.
int * getParent(int *child, int *heap) {
    if (heap != child) // if child is not the first element
    {
        return heap + ((child - heap - 1) / 4);
    }
    else // if child is the first element
    {
        return NULL;
    }
}

// Returns a pointer to the n-th child node given the pointer to the parent node
//         a pointer to the first element in the heap, and the heap size.
// n is in the range from 1 to 4.
// Note that a child may not exist (index of child >= heapSize); if so, return a null pointer.
int * getChild(int *parent, int n, int *heap, int heapSize) {
    int *child = heap + (4 * (parent - heap) + n); // getting the child index first and then getting child address
    if (child - heap < heapSize) // if child exists
    {
        return child;
    }
    else // if child does not exist
    {
        return NULL;
    }
}

// Restores the min-heap property at the element pointed by root.
// Swaps the smallest child, if it is smaller, with this element, and then recursively
//    call the function to restore the min-heap property.
void minHeapify(int *heap, int *root, int heapSize) {
    int *child1 = heap + (4 * (root - heap) + 1); // getting the child index first and then getting the address of the child
    int *child2 = heap + (4 * (root - heap) + 2);
    int *child3 = heap + (4 * (root - heap) + 3);
    int *child4 = heap + (4 * (root - heap) + 4);
    int smallest = (root - heap); // setting the index of the root to be the smallest

    if ((child1 - heap) < heapSize && *child1 < *(heap + smallest)) // if child's value is smaller than the parent
    {
        smallest = (child1 - heap); // set smallest to be the index of the child
    }

    if ((child2 - heap) < heapSize && *child2 < *(heap + smallest))
    {
        smallest = (child2 - heap);
    }

    if ((child3 - heap) < heapSize && *child3 < *(heap + smallest))
    {
        smallest = (child3 - heap);
    }

    if ((child4 - heap) < heapSize && *child4 < *(heap + smallest))
    {
        smallest = (child4 - heap);
    }

    if (smallest != (root - heap)) // if the root is not the smallest value
    {
        swap(root, (heap + smallest)); // swap the value of the root and the child with smallest value
        minHeapify(heap, (heap + smallest), heapSize); // if swapped, calling the minHeapify func again to make sure the min-heap property exists
    }
}

// Builds a heap out of an array by calling minHeapify on all necessary elements.
void buildHeap(int *arr, int heapSize) { // builds a heap from an array by calling minHeapify for every parent
    int index = ((heapSize - 1) / 4) + (((heapSize - 1) % 4) != 0) - 1;
    for (int i = index; i >= 0; i--)
    {
        minHeapify(arr, (arr + i), heapSize);
    }
}

// Sorts array arr into non-decreasing order.
// You can use only the functions you defined in the above.
void heapSort(int *arr, int heapSize) {
    buildHeap(arr, heapSize); // calling buildheap to make heap before sorting
    for (int i = heapSize - 1; i >= 0; i--) // swapping the first element (the smallest) with the last and then calling minHeapify to get the new smallest value again to swap with the new last element
    {
        swap(arr, (arr + i));
        minHeapify(arr, (arr + 0), i);
    }
    int temp;
    for (int i = 0; i < heapSize / 2; i++) // reversing an array numbers (as min-heap sorts the array in descending order)
    {
        temp = *(arr + i);
        *(arr + i) = *(arr + (heapSize - i - 1));
        *(arr + (heapSize - i - 1)) = temp;
    }
}
