#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define NUM_CHILDREN 4

void swap(int *el1, int *el2);
int *getParent(int *child, int *heap);
int *getChild(int *parent, int n, int *heap, int heapSize);
void minHeapify(int *heap, int *root, int heapSize);
void buildHeap(int *arr, int heapSize);
void heapSort(int *arr, int heapSize);

void checkBuildHeap(int *heap, int heapSize);
void checkMinHeapify(int *heap, int heapSize, int *root);
bool checkHeap(int *heap, int heapSize);
void checkGetParent(int *heap, int heapSize);
void checkGetChild(int *heap, int heapSize);
void checkHeapSort(int *arr, int heapSize);
