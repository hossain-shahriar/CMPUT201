/* Purpose: Magic square checker
 * Author: Mohammad Shahriar Hossain
 * Date: 30 September, 2022
 * Persons discussed w/:
 * References: googled magic square matrix to get an idea of how it workers
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    int n;
    printf("Enter the number of dimention of the matrix: ");
    scanf("%d", &n);
    int matrix[n][n], i, j;
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
        {
            printf("Enter number at row %d and column %d: ", i + 1, j + 1);
            if (scanf("%d", &matrix[i][j]) != 1)
            {
                printf("Invalid input."); // if the input is not a number
                return 1;
            }
        }
    for (i = 0; i < n; i++) // printing the matrix
    {
        for (j = 0; j < n; j++)
        {
            printf(" %d ", matrix[i][j]);
        }
        printf("\n");
    }

    void magicSquareChecker(int martix[n][n]) // function that checks if the matrix is magic square or not. first, it takes the diagonal sum and compare it with row sum and column sum. if diagonal sum is equals to row and column sum then it's a magic square
    {
        int result; // calculating diagonal sum
        int dsum = 0;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (i == j)
                {
                    dsum = dsum + matrix[i][j];
                }
            }
        }

        for (int i = 0; i < n; i++) // calculating row sum and comparing it with diagonal sum
        {
            int rsum = 0;
            for (int j = 0; j < n; j++)
            {
                rsum = rsum + matrix[i][j];
            }
            if (dsum == rsum)
            {
                result = 1;
            }
            else
            {
                result = 0;
                break;
            }
        }

        for (int i = 0; i < n; i++) // calculating column sum and comparing it with diagonal sum
        {
            int csum = 0;
            for (int j = 0; j < n; j++)
            {
                csum = csum + matrix[j][i];
            }
            if (dsum == csum)
            {
                result = 1;
            }
            else
            {
                result = 0;
                break;
            }
        }
        if (result == 1) // if diagonal sum is equals to row and column sum
        {
            printf("\nValid magic square");
        }
        else if (result == 0) // if not diagonal sum is equals to row and column sum
        {
            printf("\nInvalid magic square");
        }
    }

    magicSquareChecker(matrix); // calling the function

    return 0;
}
