/* Purpose: Expression interpreter
 * Author: Mohammad Shahriar Hossain
 * Date: 30 September, 2022
 * Persons discussed w/:
 * References: https://www.youtube.com/watch?v=f8589Y9LHHg&ab_channel=PortfolioCourses
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    char str[100];
    int result;
    printf("Enter an expression: ");
    scanf("%[^\n]%*c", str);            // to take spaces as well. watch the video in the references.
    if (str[0] >= '0' && str[0] <= '9') // if the first index is a number, then add it to result, otherwise terminate the program.
    {
        result = str[0] - '0';
    }
    else
    {
        return 1;
    }
    int i = 1;
    while (str[i] != '\0') // while the string does not end
    {
        if ((str[i] == '+' || str[i] == '-') && (str[i + 1] >= '0' && str[i + 1] <= '9')) // if every odd index is a number and every even is an operator, otherwise terminate the program.
        {
            char operator= str[i];
            char operand = str[i + 1];
            if (operator== '+')
            {
                result = result + (operand - '0');
            }
            else if (operator== '-')
            {
                result = result - (operand - '0');
            }
            else
            {
                return 1;
            }
        }
        else
        {
            return 1;
        }

        i += 2;
    }
    printf("The value of this expression is: %d", result);

    return 0;
}
