/* Purpose: Sorting and searching
 * Author: Mohammad Shahriar Hossain
 * Date: 30 September, 2022
 * Persons discussed w/:
 * References: Googled "Selection sort in c programming" and "Binary search in c programming" and got the idea and implemented the code myself
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
  int n;
  char alpha, target;
  printf("Enter the number of alphabetical characters: ");
  scanf("%d", &n);
  char str[n];
  printf("Enter %d alphabetical characters to be sorted: ", n);
  for (int i = 0; i < n; i++)
  {
    scanf(" %c", &alpha);
    if ((alpha >= 'A' && alpha <= 'Z') || (alpha >= 'a' && alpha <= 'z')) // only take input if input is alphabetical characters
    {
      str[i] = alpha;
    }
    else if (alpha == ' ') // ignoring white spaces
    {
      i--;
    }
    else if (alpha != ' ') // if the input is not an alphabetical character
    {
      printf("Illegal character detected\n");
      return 1;
    }
    }
  scanf("%*[^\n]"); // Scanning past any invalid input
  str[n] = '\0';

  printf("\n%s\n", str);

  // ******************** SELECTION SORT ***********************
  void selectionSort(int n, char str[])
  {
    for (int i = 0; i < (n - 1); i++)
    {
      int index = i;
      for (int j = i + 1; j < n; j++)
      {
        if (str[index] < str[j])
          index = j;
      }
      if (index != i)
      {
        char temp = str[i];
        str[i] = str[index];
        str[index] = temp;
      }
    }
  }
  // ******************** SELECTION SORT ***********************

  // ******************** BINARY SEARCH ***********************

  int binarySearch(int low, int high, char str[], char target)
  {
    // Repeat until the pointers low and high meet each other
    while (low <= high)
    {
      int mid = low + (high - low) / 2;

      if (str[mid] == target)
      {
        return mid;
      }
      if (str[mid] > target)
      {
        low = mid + 1;
      }
      else if (str[mid] < target)
      {
        high = mid - 1;
      }
    }

    return -1;
  }
  // ******************** BINARY SEARCH ***********************

  selectionSort(n, str); // calling selection sort function
  printf("In reverse alphabetical order: %s\n", str);
  printf("Enter the character you wish to locate: ");
  scanf(" %c", &target);
  int result = binarySearch(0, n - 1, str, target); // calling binary search function
  printf("%c is located at position: %d", target, result);

  return 0;
}
