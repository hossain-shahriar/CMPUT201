/* Purpose: Recursive fibonacci
 * Author: Mohammad Shahriar Hossain
 * Date: October 14, 2022
 * References: https://www.youtube.com/watch?v=UxICsjrdlJA&t=457s
 */

#include "lab06.h"

int main() {
    int n = 20;
    printf("The number of calls for n = %d is: \n", n);
    check_tri(n);
    
    test();
    return 0;
}


// Calculates the x-th tribonacci number.
// 1) You should have a variable inside the function that counts the number of calls
//    over the lifetime of the program.
// 2) This function should be pure recursion - no memoization or dynamic programming allowed.
int a;
int tri1(int x) {
    a++;
    if (x == 0 || x == 1 || x == 2)
    {
        return x;
    }
    else
    {
        return tri1(x-1) + tri1(x-2) + tri1(x-3);
    }
}


// Calculates the x-th tribonacci number.
// 1) You should have a variable inside the function that counts the number of calls
//    over the lifetime of the program.
// 2) This function should store the values of previous calls to fib2 in an array
//    and use them for later calculations.
int b;
int tria[101];
int tri2(int x) {
    b++;
    if (x == 0 || x == 1 || x == 2)
    {
        return tria[x] = x;
    }
    else if (tria[x] != 0)
    {
        return tria[x];
    }
    else
    {
        tria[x] = tri2(x - 1) + tri2(x - 2) + tri2(x - 3);
        return tria[x];
    }
}


// Checks the two tribonacci functions tri1 and tri2.
// 1) Your program should print the number of calls made to tri1, and the number
//    of calls made to tri2.
void check_tri(int x) {
    tri1(x);
    tri2(x);
    printf("tri1 was called %d times.\n", a);
    printf("tri2 was called %d times.\n", b);
}
