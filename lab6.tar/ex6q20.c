#include "lab06.h"

int count_assign;
int count_comp;

// The function below assigns the value at the address `b` to the storage with address `a`
void keyassign(int *a, int *b) {
    count_assign++;
    *a = *b;
}

// The function below compares two integers, and returns true if and only if a <= b
bool keycomp(int a, int b) {
    count_comp++;
    if (a <= b)
    {
        return true;
    }
    else
    {
        return false;
    }
}
