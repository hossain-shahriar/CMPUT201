#include "lab06.h"

// The following function compares all 3 sorting algorithms you have defined earlier.
//  1) Call all 3 functions on array `a` (or on its copy) of length n
//  2) Then, print out the number of key comparisons and assignments per each sort
void comparesort(int a[], int n) {
    int x[n], y[n], z[n];
    for (int i = 0; i < n; i++)
    {
        x[i] = a[i];
        y[i] = a[i];
        z[i] = a[i];
    }
    printf("Running sorting functions on array [");
    for (int i = 0; i < n; i++)
    {
        if (i != n - 1)
        {
            printf("%d, ", a[i]);
        }
        else
        {
            printf("%d]\n\n", a[i]);
        }
    }
    count_assign = 0;
    count_comp = 0;
    bubble_sort(x, n);
    printf("Bubble Sort:\n- %d key assignments\n- %d key comparisons\n\n", count_assign, count_comp);
    count_assign = 0;
    count_comp = 0;
    insertion_sort(y, n);
    printf("Insertion Sort:\n- %d key assignments\n- %d key comparisons\n\n", count_assign, count_comp);
    count_assign = 0;
    count_comp = 0;
    int left = 0, right = n - 1;
    merge_sort(z, left, right);
    printf("Merge Sort:\n- %d key assignments\n- %d key comparisons\n\n", count_assign, count_comp);
}
