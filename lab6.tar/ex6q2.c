/* Purpose: Sorting functions
 * Author: Mohammad Shahriar Hossain
 * Date: October 14, 2022
 * References: https://www.geeksforgeeks.org/bubble-sort/
 * https://www.geeksforgeeks.org/insertion-sort/
 * https://www.geeksforgeeks.org/merge-sort/
 */

#include "lab06.h"

int main(int argc, char **argv) {
    int a[10] = {99, 100, 34, 12, 11, 1, 23, -2, 3, 1};
    comparesort(a, 10);

    check_sorts();
    return 0;
}
