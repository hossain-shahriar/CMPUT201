#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

extern int count_assign;
extern int count_comp;

int tri1(int x);
int tri2(int x);
void check_tri(int x);
void test(void);
void testing_q1(int (*tri)(int), int x, int correctRes);

void keyassign(int *a, int *b);
bool keycomp(int a, int b);
void bubble_sort(int arr[], int n);
void insertion_sort(int arr[], int n);
void merge_sort(int a[], int left, int right);
void merge(int a[], int left, int mid, int right);
void check_sorts(void);
void comparesort(int a[], int n);
