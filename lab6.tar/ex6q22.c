#include "lab06.h"

// The following function insertionsorts an array into increasing order.
// 1) to sort an array of n integers into increasing order
// 2) if an assignment operation involves an array element, use keyassign()
// 3) if a comparison operation involves an array element, use keycomp()
// 4) should be in-space sorting:
//  4.1) shuffle elements inside of the array
//  4.2) no extra arrays can be used for sorting
void insertion_sort(int arr[], int n) {
    for (int i = 1; i < n; i++)
    {
        int key = arr[i];
        int j = i - 1;
        /* Move elements of arr[0..i-1], that are
          greater than key, to one position ahead
          of their current position */
        // while (j >= 0 && arr[j] > key) {
        while (j >= 0 && (keycomp(arr[j], key) == false))
        {
            // arr[j + 1] = arr[j];
            keyassign(&arr[j + 1], &arr[j]);
            j = j - 1;
        }
        // arr[j + 1] = key;
        keyassign(&arr[j + 1], &key);
    }
}
