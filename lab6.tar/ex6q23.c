#include "lab06.h"

// The following function mergesorts an array into increasing order.
// Complete the following function as a recursion:
// 1) to sort an array of integers a[left ... right] (from position 'left' to position 'right') into increasing order
// 2) if an assignment operation involves an array element, use keyassign()
// 3) if a comparison operation involves an array element, use keycomp()
// 4) should be a recursion:
//  4.1) divide into two subarrays of equal length (or off by 1)
//  4.2) recursively mergesort each subarray
//  4.3) merge the two sorted subarrays
void merge_sort(int a[], int left, int right) {
    // if (left < right)
    if ((keycomp(right, left)) == false)
    {
        // Same as (left+right)/2, but avoids overflow for
        // large left and right
        int mid = left + (right - left) / 2;
        // Sort first and second halves
        merge_sort(a, left, mid);
        merge_sort(a, mid + 1, right);
        merge(a, left, mid, right);
    }
}


// the following function merges a[left ... mid] and a[mid+1 ... right]
// complete the function definition:
// 1) you may assume that a[left ... mid] and a[mid+1 ... right] are sorted separately
void merge(int a[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;
    /* create temp arrays */
    int L[n1], R[n2];
    /* Copy data to temp arrays L[] and R[] */
    for (int i = 0; i < n1; i++)
    {
        // L[i] = a[left + i];
        keyassign(&L[i], &a[left + i]);
    }
    for (int j = 0; j < n2; j++)
    {
        // R[j] = a[mid + 1 + j];
        keyassign(&R[j], &a[mid + 1 + j]);
    }
    /* Merge the temp arrays back into a[left..right]*/
    int i = 0;    // Initial index of first subarray
    int j = 0;    // Initial index of second subarray
    int k = left; // Initial index of merged subarray
    // while (i < n1 && j < n2)
    while (((keycomp(n1, i)) == false) && ((keycomp(n2, j)) == false))
    {
        // if (L[i] <= R[j])
        if ((keycomp(L[i], R[j])) == true)
        {
            // a[k] = L[i];
            keyassign(&a[k], &L[i]);
            i++;
        }
        else
        {
            // a[k] = R[j];
            keyassign(&a[k], &R[j]);
            j++;
        }
        k++;
    }
    /* Copy the remaining elements of L[], if there
    are any */
    // while (i < n1)
    while ((keycomp(n1, i)) == false)
    {
        // a[k] = L[i];
        keyassign(&a[k], &L[i]);
        i++;
        k++;
    }
    /* Copy the remaining elements of R[], if there
    are any */
    // while (j < n2)
    while ((keycomp(n2, j)) == false)
    {
        // a[k] = R[j];
        keyassign(&a[k], &R[j]);
        j++;
        k++;
    }
}
