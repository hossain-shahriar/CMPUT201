/* Purpose: Product finder
 * Author: Mohammad Shahriar Hossain
 * Date: 24 November, 2022
 * References: googled how half-precision, single-precision and double-precision work. Also watched some videos on how bitmasking works. as string.h was not given, I couldn't use strcpy, instead, I used sprinf (googled how to convert float to string in c and got this "https://www.geeksforgeeks.org/what-is-the-best-way-in-c-to-convert-a-number-to-a-string/")
 */

#include "lab12.h"

int main() {
    // Feel free to add some checks here
    // To visualize things, you can use the pre-defined function
    // char *format_float32_bits(float f);

    return test_pls(); // Leave this part to run our checks
}

// Returns the sign of a 16-bit float. 1 if it's negative, 0 if it's positive
int get_sign(float16 f) {
    return (((1 << 1) - 1) & (f >> 15));
}

// Returns the **value** of the exponent in a 16-bit float. This'll be the base-10
// integer value of that exponent.
//
//                 01001
//   ┌─────────────┘│││└─────────────┐
//   │       ┌──────┘│└──────┐       │
//   │       │       │       │       │       ┌Don't forget to subtract off bias
//   0*2^4 + 1*2^3 + 0*2^2 + 0*2^1 + 1*2^0 - bias
//
// Don't worry about it being infinity or NaN, just calculate out the exponent
// as if it were an integer
int get_exponent(float16 f) {
    return ((((1 << 5) - 1) & (f >> 10)) - 15);
}

// We already implemented this one for you. It returns a signed infinity as a
// 32-bit float
float float32_infinity(int sign) {
    unsigned f = 0x7F800000;
    if (sign < 0)
		f |= 1 << 31;
    // The line below reinterprets the bits of "f" as a float. This is
    // different from casting, which tries to convert the value
    return * (float *) &f;
}

// Returns a NaN as a 32-bit float. (Look at float32_infinity() for a hint)
float float32_nan() {
    unsigned f = 0x7f8f0000;
    return *(float *)&f;
}

// Returns true when the float16 is showing a NaN. False in all other cases
bool is_nan(float16 f) {
    if (get_exponent(f) == 16 && (unsigned)(f & 0x3FF) != 0)
    {
        return true;
    }
    else
        return false;
}

// This function is mostly implemented... assuming the functions you've
// implemented above are correct
//
// Returns 0 when the float isn't infinity
// Returns 1 when the float is positive infinity
// Returns -1 when the float is negative infinity
int is_infinity(float16 f) {
    if (get_exponent(f) == 16 && (unsigned) (f & 0x3FF) == 0) {
        // sign = 0 =>  1 since 0*-2+1 = 1
        // sign = 1 => -1 since 1*-2+1 = -1
        return get_sign(f) * -2 + 1;
    }
	else
        return 0;
}

// Returns a string representation of the bits of a 16-bit float. The output should have a single space between parts. Example:
//
//    ┌Single space
//    │     ┌Single space
//    │     │
//  "1 01010 0001111101"
//   │ └─┬─┘ └───┬────┘
//   │   │       └Mantissa (10 bits)
//   │   └Exponent (5 bits)
//   └Sign (1 bit)
//
// Don't put a \n at the end!
char *format_float16_bits(float16 f) {
    char *ptr = (char *)malloc(19);
    for (int i = 15; i >= 0; i--)
    {
        ptr[15 - i] = ((f >> i) & 1) + 48;
    }
    for (int i = 15; i >= 1; i--)
    {
        ptr[i + 1] = ptr[i];
    }
    for (int i = 16; i >= 7; i--)
    {
        ptr[i + 1] = ptr[i];
    }
    ptr[1] = ' ';
    ptr[7] = ' ';
    ptr[18] = '\0';
    return ptr;
}

// Converts a 16-bit float into a 32-bit float and returns it. The 32-bit float
// needs to have (approximately) the same value as the original 16-bit float.
// We'll be looking for an accuracy of 3 decimal points
//
// If the float16 was NaN or a signed infinity, the float16 should also be NaN
// or the same signed infinity. Consider using the float32_nan() and
// float32_infinity() from before
float float16_to_float32(float16 f) {
    if (is_nan(f) || is_infinity(f))
    {
        if (is_nan(f))
        {
            return float32_nan();
        }
        else
        {
            return float32_infinity(get_sign(f));
        }
    }
    else
    {
        int f32 = (get_sign(f)) << 31;
        f32 |= (get_exponent(f) + 127) << 23;
        f32 |= (f & 0x03FF) << 13;
        return *(float *)&f32;
    }
}

// Return the string representation the value of a 16 bit float to 4 decimal
// places. Think of it like printf("%.4f", f) it's using a 16-bit float and it
// returns the string instead of printing it. Return "NaN" and "Infinity" or
// "-Infinity" when the float16 is one of those
//
// Examples:
//   "1.3453"
//   "-3233.332"
//   "NaN"
//   "Infinity"
//   "-Infinity"
//   "10.0000"
//
// We only test for accuracy in the first 3 decimal places, just in case
// there's rounding error. Do not include a '\n' at the end! DO include a null
// character at the end
char *format_float16(float16 f) {
    if (is_infinity(f) && get_sign(f) == 1)
    {
        char *str = (char *)malloc(10 * sizeof(char));
        sprintf(str, "-infinity");
        return str;
    }
    else if (is_infinity(f) && get_sign(f) == 0)
    {
        char *str = (char *)malloc(9 * sizeof(char));
        sprintf(str, "Infinity");
        return str;
    }
    else if (is_nan(f))
    {
        char *str = (char *)malloc(4 * sizeof(char));
        sprintf(str, "NaN");
        return str;
    }
    else
    {
        char *str = (char *)malloc(17 * sizeof(char));
        float f32 = float16_to_float32(f);
        sprintf(str, "%.4f", *(float *)&f32);
        return str;
    }
}
