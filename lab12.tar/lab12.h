#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>

typedef unsigned short float16;
typedef unsigned short sale;

// For part 1
unsigned int get_product(sale x);
unsigned int get_quantity(sale x);
unsigned int get_purchaser(sale x);
bool is_discounted(sale x);
void print_sale(sale x, const char *product_names[]);

// For testing part 1
int test();

// For part 2
int get_sign(float16 f);
int get_exponent(float16 f);
float float32_infinity(int sign);  // Already done
float float32_nan();
bool is_nan(float16 f);
int is_infinity(float16 f);  // Already done, if the above work
char *format_float16_bits(float16 f);
float float16_to_float32(float16 f);
char *format_float16(float16 f);

// For testing part 2
int test_pls();  // We run our entire test suite
char *format_float32_bits(float f);  // Like the one you implement for 16bits
