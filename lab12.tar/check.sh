#!/usr/bin/bash
# Check script given for lab 12
#
# Written in Fall 2022 for CMPUT 201 @ University of Alberta
# by Akemi Izuko <akemi.izuko@ualberta.ca>
umask 077
shopt -s lastpipe

declare -r TMP_DIR="$(mktemp -d --tmpdir=/dev/shm)"  # Shared mem is big enough?
declare -r REQUIRED_FILES=(\
  ex12q1.c
  ex12q2.c
  lab12a.o
  lab12b.o
  lab12.h
  check.sh
  Makefile
)

print_help() {
  cat <<HELP
Check file for lab 12

USAGE:
    $0 submit.tar
    bash $0 submit.tar
HELP
}

assert_lab_machine() {
  if [[ "$(hostname)" =~ ^ug[0-9]{2}$ || "$(hostname)" == ohaton ]]; then
    return 0
  else
    return 1
  fi
}

check_mem_leaks() {
  local -i valgrind_out=0
  local exe="$1"
  local name="$2"
  local input="$3"

  # Checks for heap memory leaks
  printf "\nChecking for memory leaks (this might appear to freeze for a second)\n"

  if [[ -n "$input" ]]; then
    valgrind "$exe" < "$input" 2> "${TMP_DIR}/valgrind_out" >/dev/null
  else
    valgrind "$exe" 2> "${TMP_DIR}/valgrind_out" >/dev/null
  fi

  awk 'match($0, /in use at exit/) {
    split($0, a, " ");
    printf "%d", a[6];
  }' "${TMP_DIR}/valgrind_out" | read -r valgrind_out

  if [[ "$valgrind_out" -ne 0 ]]; then
    cat <<LEAKED
Memory leaks detected in ${name}!
Marks will be taken off for memory leaks
Leaked $valgrind_out bytes
LEAKED
    return 1
  else
    printf "%s did not leak memory! Good stuff\n\n" "$name"
    return 0
  fi
}

if ! [[ -r "$1" ]]; then
  print_help
  exit 1
elif ! assert_lab_machine; then
    echo " \`$(hostname) \` is not a lab machine!"
    echo "Please scp your files to a lab machine and run this check script there"
    exit 1
else
  # Untar file
  if ! tar -C "$TMP_DIR" -xf "$1"; then
    echo "Something is wrong with the tar file \"${1}\""
    exit 1
  fi

  # Check to make sure all files are present
  for file in "${REQUIRED_FILES[@]}"; do
    if ! [[ -e "${TMP_DIR}/${file}" ]]; then
      echo "You're missing \"${file}\" in your submission"
      exit 1
    fi
  done

  echo "Opened $1 into \`${TMP_DIR}\`"

  # Compile and check the only part
  declare -i return_val=0

  # Check part 1 ====
  if ! make -C "$TMP_DIR" ex12q1; then
    echo "ex12q1.c compiled with errors!"
    echo "Programs must compile without errors for full marks"
    return_val=1
  fi

  if ! "${TMP_DIR}/ex12q1"; then
    echo "ex12q1.c exited with non-zero exit code"
  fi

  #if ! check_mem_leaks "${TMP_DIR}/ex11q1" "ex11q1.c" "${TMP_DIR}/graph.txt"; then
  #  return_val=1
  #fi

  # Check part 2 ====
  if ! make -C "$TMP_DIR" ex12q2; then
    echo "ex12q2.c compiled with errors!"
    echo "Programs must compile without errors for full marks"
    return_val=1
  fi

  if ! "${TMP_DIR}/ex12q2"; then
    echo "ex12q2.c exited with non-zero exit code"
    return_val=1
  fi

  #if ! check_mem_leaks "${TMP_DIR}/ex11q2" "ex11q2.c"; then
  #  return_val=1
  #fi

  if [[ $return_val -eq 0 ]]; then
    echo "All checks passed!"
    echo "If you feel you've tested enough, you can submit. Good luck!"
  fi

  exit $return_val
fi
