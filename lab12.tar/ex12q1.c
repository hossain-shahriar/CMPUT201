/* Purpose: Product finder
 * Author: Mohammad Shahriar Hossain
 * Date: 24 November, 2022
 * References: https://www.geeksforgeeks.org/extract-k-bits-given-position-number/
 */

#include "lab12.h"

int main() {
    const char *product_names[] = {
        "brake pads", "headlights", "battery", "motor oil",
        "tires", "hubcaps", "windshield fluid", "spark plug",
        "exhaust pipe", "side mirror", "suspension", "brake disc",
        "muffler", "radiator", "seat", "bumper"
    };
    sale x = 13476;   // binary: 0011010010100100
    print_sale(x, product_names);

    return test();
}


// return the product ID
unsigned int get_product(sale x) {
    return (((1 << 4) - 1) & (x >> 12));
}

// return the quantity purchased
unsigned int get_quantity(sale x) {
    return (((1 << 4) - 1) & (x >> 8));
}

// return the purchaser ID
unsigned int get_purchaser(sale x) {
    return (((1 << 7) - 1) & (x >> 0));
}

// return whether the product was discounted or not
bool is_discounted(sale x) {
    return (((1 << 1) - 1) & (x >> 7));
}

// given a sale x and an array of product names, print out the sale like in the format below
void print_sale(sale x, const char *product_names[]) {
    printf("product ID: %d\n", get_product(x));
    printf("product name: %s\n", product_names[get_product(x)]);
    printf("quantity purchased: %d\n", get_quantity(x));
    if (is_discounted(x) == true)
    {
        printf("discount: True\n");
    }
    else
    {
        printf("discount: False\n");
    }
    printf("purchaser ID: %d\n", get_purchaser(x));
}
