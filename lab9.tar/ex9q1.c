/* Purpose: String processing
 * Author: Mohammad Shahriar Hossain
 * Date: 4th November, 2022
 * References: https://www.youtube.com/watch?v=tGgl6EMZxLU&t=817s
 */
#include "lab09.h"

int main() { //Do NOT add anything inside main function!
    test_part_1();  // Will run the tests for you
    return 0;
}

// the following function returns a pointer to the string after substitutions
// replace any occurrence of the string `x` in `str` with the `replace` string
// complete the function definition:
// 1) you can assume that `x` contains only lower-case alphabetic characters
// 2) you are not allowed to change the strings passed to the function
// 3) you will have to allocate a new string for the result and return it
// 4) you do not have to free the dynamically allocated memory for the new string
char *globalSubstitute(const char *str, const char *x, const char *replace) {
    int len_x = strlen(x); // getting the lens of the strings
    int len_replace = strlen(replace);
    int len_str = strlen(str);
    char *str1;
    if (len_x == len_replace)
    {
        str1 = malloc((len_str + 1) * sizeof(char)); // allocating same amount of space because the len of x and replace is same
    }
    else
    {
        int count = 0; // how many times x occurs in str

        int i = 0;
        while (i < len_str)
        {
            if (strstr((str + i), x) == (str + i)) // if substring is equals to x
            {
                count++;
                i += len_x; // skipping the len of x
            }
            else
                i++;
        }

        int len_diff = len_replace - len_x; // difference between the lens of x and replace
        int len_str1 = len_str;             // initially setting the len to be the same as the original str len.
        len_str1 += count * len_diff;       // increase or decrease the len according to the count and len difference

        str1 = malloc((len_str1 + 1) * sizeof(char)); // allocating space for str1 if difference between len_x and len_replace exists
    }

    int i = 0, j = 0;

    while (i < strlen(str))
    {
        if (strstr((str + i), x) == (str + i)) // if substring is equals to x
        {
            strcpy((str1 + j), replace); // replacing the substring

            i += len_x; // skip through the len of replace

            j += len_replace; // the len of i and j might be different
        }
        else
        {
            *(str1 + j) = *(str + i);
            i++;
            j++;
        }
    }
    *(str1 + j) = '\0'; // adding null character to the new string
    return str1;
}

// the following function returns a pointer to a new string representing the string `str` rotated right by m places
// complete the function definition:
// 1) you can assume that `m` is a non-negative integer
// 2) you are not allowed to change the string passed to the function
// 3) you will have to allocate a new string for the result and return it
// 4) you do not have to free the dynamically allocated memory for the new string
char *stringRotate(const char *str, int m) {
    char *str1 = (char *)calloc((strlen(str) + 1), sizeof(char)); // allocating space for new string
    char *str2 = (char *)calloc((m + 1), sizeof(char));           // allocating space for storing the substring
    strcpy(str1, str);                                            // copy str to str1
    int a = 0;
    for (int i = strlen(str) - m; i < strlen(str); i++)
    {
        *(str2 + a++) = *(str + i); // storing the substring
    }
    *(str2 + a) = '\0'; // adding null character
    for (int j = 1; j < (strlen(str) - m + 1); j++)
    {
        *(str1 + (strlen(str) - j)) = *(str1 + (strlen(str) - m - j)); // shifting the values right one by one
    }
    for (int k = 0; k < m; k++)
    {
        *(str1 + k) = *(str2 + k); // adding substring at the start of the new string
    }
    *(str1 + strlen(str)) = '\0'; // adding null character
    free(str2);                   // freeing extra allocated memory
    return str1;
}

// the following function returns a new string that represents the string `str` after shifting pairs
// complete the function definition:
// 1) you can assume that `n` is an integer between 1 and 26
// 2) you are not allowed to change the string passed to the function
// 3) you will have to allocate a new string for the result and return a pointer to it
// 4) you do not have to free the dynamically allocated memory for the new string
char *pairShift(const char *str, int n) {
    char *str1 = (char *)calloc((strlen(str) + 1), sizeof(char)); // allocating memory
    strcpy(str1, str);                                            // copying the string
    *(str1 + strlen(str)) = '\0';                                 // adding null character
    for (int i = 0; i < strlen(str); i = i + 2)                   // traversing the string by two
    {
        if (i < strlen(str) && (*(str + i) + (n + (i / 2))) <= 122) // if the value is in range (within 97 and 122)
        {
            *(str1 + i) = *(str + i) + (n + (i / 2));
        }
        else if (i < strlen(str) && (*(str + i) + (n + (i / 2))) > 122) // if the value is not in range (within 97 and 122)
        {
            int result = ((*(str + i) + n + (i / 2)) % 122) + 96;
            while (result > 122)
            {
                result = (result % 122) + 96;
            }

            *(str1 + i) = result;
        }
        if ((i + 1) < strlen(str) && (*(str + i + 1) + (n + (i / 2))) <= 122) // if the value is in range (within 97 and 122)
        {
            *(str1 + i + 1) = *(str + i + 1) + (n + (i / 2));
        }
        else if ((i + 1) < strlen(str) && (*(str + i + 1) + (n + (i / 2))) > 122) // if the value is not in range (within 97 and 122)
        {
            int result = ((*(str + i + 1) + n + (i / 2)) % 122) + 96;
            while (result > 122)
            {
                result = (result % 122) + 96;
            }
            *(str1 + i + 1) = result;
        }
    }
    return str1;
}

