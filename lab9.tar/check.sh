#!/usr/bin/bash
# Check script given for lab 9. The following is checked:
# - The tar has all required files
# - All 3 programs compile without warnings
# - Runs programs on the cases presented in the lab description
#
# Written in Fall 2022 for CMPUT 201 @ University of Alberta
# by Akemi Izuko <akemi.izuko@ualberta.ca>
umask 077
shopt -s lastpipe

declare -r TMP_DIR="$(mktemp -d --tmpdir=/dev/shm)"  # Shared mem is big enough?
declare -r REQUIRED_FILES=(\
  ex9q1.c
  ex9q2.c
  lab09.h
  lab09a.o
  lab09b.o
  check.sh
)

print_help() {
  cat <<HELP
Check file for lab 9

USAGE:
    $0 submit.tar
    bash $0 submit.tar
HELP
}

assert_lab_machine() {
  if [[ "$(hostname)" =~ ^ug[0-9]{2}$ || "$(hostname)" == ohaton ]]; then
    return 0
  else
    return 1
  fi
}

check_mem_leaks() {
  local -i valgrind_out=0
  local exe="$1"
  local name="$2"

  # Checks for heap memory leaks
  printf "Right before\n"

  valgrind "$exe" "$3" "$4" 2> "${TMP_DIR}/valgrind_out"

  awk 'match($0, /in use at exit/) {
    split($0, a, " ");
    printf "%d", a[6];
  }' "${TMP_DIR}/valgrind_out" | read -r valgrind_out

  if [[ "$valgrind_out" -ne 0 ]]; then
    cat <<LEAKED
Memory leaks detected in ${name}!
Marks will be taken off for memory leaks
Leaked $valgrind_out bytes
LEAKED
    return 1
  else
    echo "$name did not leak memory! Good stuff"
    return 0
  fi
}

if ! [[ -r "$1" ]]; then
  print_help
  exit 1
elif ! assert_lab_machine; then
    echo " \`$(hostname) \` is not a lab machine!"
    echo "Please scp your files to a lab machine and run this check script there"
    exit 1
else
  # Untar file
  if ! tar -C "$TMP_DIR" -xf "$1"; then
    echo "Something is wrong with the tar file \"${1}\""
    exit 1
  fi

  # Check to make sure all files are present
  for file in "${REQUIRED_FILES[@]}"; do
    if ! [[ -e "${TMP_DIR}/${file}" ]]; then
      echo "You're missing \"${file}\" in your submission"
      exit 1
    fi
  done

  # Compile and check the only part
  declare -i return_val=0

  # Check part 1 ====
  if ! gcc -Wall -std=c99 "${TMP_DIR}/ex9q1.c" "${TMP_DIR}/lab09a.o" -o "${TMP_DIR}/ex9q1"
  then
    echo "ex9q1.c compiled with errors!"
    echo "Programs must compile without errors for full marks"
    return_val=1
  fi

  if ! "${TMP_DIR}/ex9q1"; then
    echo "ex9q1.c exited with non-zero exit code"
  fi

  if ! check_mem_leaks "${TMP_DIR}/ex9q1" "ex9q1.c"; then
    return_val=1
  fi

  # Check part 1 ====
  if ! gcc -Wall -std=c99 "${TMP_DIR}/ex9q2.c" "${TMP_DIR}/lab09b.o" -o "${TMP_DIR}/ex9q1"
  then
    echo "ex9q2.c compiled with errors!"
    echo "Programs must compile without errors for full marks"
    return_val=1
  fi

  if ! "${TMP_DIR}/ex9q1" 123123123123123123123123 45678; then
    echo "ex9q2.c failed with input numbers 123123123123123123123123 45678"
    return_val=1
  elif ! "${TMP_DIR}/ex9q1" 680564733841876926926749214863536422912 0; then
    echo "ex9q2.c failed with inupt numbers 680564733841876926926749214863536422912 0"
    return_val=1
  fi

  if ! check_mem_leaks "${TMP_DIR}/ex9q2" "ex9q2.c" 123123123123123123123123 45678; then
    return_val=1
  fi

  if [[ $return_val -eq 0 ]]; then
    echo "All checks passed!"
    echo "If you feel you've tested enough, you can submit. Good luck!"
  fi

  rm -rf "${TMP_DIR}"
  exit $return_val
fi
