#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define ALPHABET_MAX 122
#define ALPHABET_MIN 97 //char in between them are lower-case alphabetical
#define ALPHABET_COUNT 26

char *globalSubstitute(const char *, const char *, const char *);
char *stringRotate(const char *, int);
char *pairShift(const char *, int);

bool validate(const char *);
char *add(const char *, const char *);
char *diff(const char *, const char *);
bool gt(const char *, const char *);
bool eq(const char *, const char *);

void check_validate(const char *);
void check_add(const char *, const char *);
void check_eq(const char *, const char *);
void check_gt(const char *, const char *);
void check_diff(const char *, const char *);
void check_globalSubstitute(const char *, const char *, const char *);
void check_stringRotate(const char *, int);
void check_pairShift(const char *, int);

void test_part_1();
void test_part_2(int argc, char **argv);
