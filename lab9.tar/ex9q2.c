/* Purpose: String algebra
 * Author: Mohammad Shahriar Hossain
 * Date: 4th November, 2022
 * References: https://www.geeksforgeeks.org/difference-of-two-large-numbers/
 * https://www.geeksforgeeks.org/sum-two-large-numbers/
 * https://www.geeksforgeeks.org/program-to-reverse-a-string-using-pointers/
 */
#include "lab09.h"

int main(int argc, char **argv) { //Do NOT add anything inside the main function
    test_part_2(argc, argv);      //Will run the tests for you. Specifiy the two number-strings as arguments
    return 0;
}

//the following function validates whether the string `p` represents a non-negative integer
//complete the function definition:
// 1) `p` is valid (not NULL);
// 2) a valid non-negative integer representation is either "0" or a sequence of digits w/o leading zeros
//    examples: "5678" corresponds to the integer 5678
//           "0" corresponds to the integer 0 (zero)
//           "005678" is invalid
//           "00" is invalid
//           "-1" is invalid
//           "123abc45" is invalid
// 3) return true iff `p` represents a valid non-negative integer
bool validate(const char *p) {
    int len = strlen(p);
    if (len == 1 && *(p + 0) == '0') // if there is only one element and that is 0
    {
        return true;
    }
    else if (*(p + 0) > 48 && *(p + 0) <= 57) // if the first element is in range
    {
        for (int i = 1; i < len; i++)
        {
            if (*(p + i) < 48 || *(p + i) > 57) // if all the elements is in range
            {
                return false;
            }
        }
    }
    else
    {
        return false;
    }
    return true;
}


//the following function validates whether m > n
//complete the function definition:
// 1) you can assume both m and n represent valid non-negative integers
// 2) return true iff m > n
bool gt(const char *m, const char *n) {
    int n1 = strlen(m), n2 = strlen(n);

    if (n2 < n1)
    {
        return true;
    }
    if (n1 < n2)
    {
        return false;
    }

    for (int i = 0; i < n1; i++)
    {
        if (*(m + i) > *(n + i)) // comparing value at index i
        {
            return true;
        }
        else if (*(m + i) < *(n + i))
        {
            return false;
        }
    }

    return false;
}

// the following function validates whether m == n
// complete the function definition:
// 1) you can assume both m and n represent valid non-negative integers
// 2) return true iff m == n
bool eq(const char *m, const char *n) {
    int n1 = strlen(m), n2 = strlen(n);

    if (n2 == n1)
    {
        for (int i = 0; i < n1; i++)
        {
            if (*(m + i) != *(n + i)) // if not equal
            {
                return false;
            }
        }
        return true;
    }
    return false;
}

//the following function returns a new string representing m + n
//complete the function definition:
// 1) you can assume both m and n represent valid non-negative integers
// 2) you do not need to free the dynamically allocate memory for the new string
char *add(const char *m, const char *n) {
    char *str1 = (char *)calloc((strlen(m) + 1), sizeof(char)); // allocating space for str1
    strcpy(str1, m);                                            // copying the string to str1
    char *str2 = (char *)calloc((strlen(n) + 1), sizeof(char)); // allocating space for str2
    strcpy(str2, n);                                            // copying the string to str2

    if (strlen(str1) > strlen(str2)) // making sure str2 is greater than str1
    {
        char *temp = str1;
        str1 = str2;
        str2 = temp;
    }

    char *str = (char *)calloc((strlen(str2) + 2), sizeof(char)); // allocating space to store result

    *str = '0'; // adding null character

    int n1 = strlen(str1), n2 = strlen(str2);

    // Reverse strings
    //*******reversing a string************ START
    char *begin1, *end1, temp1;
    begin1 = str1;
    end1 = str1;
    for (int c = 0; c < (strlen(str1) - 1); c++)
    {
        end1++;
    }
    for (int c = 0; c < strlen(str1) / 2; c++)
    {
        temp1 = *end1;
        *end1 = *begin1;
        *begin1 = temp1;
        begin1++;
        end1--;
    }
    //*******reversing a string************ END
    //*******reversing a string************ START
    char *begin2, *end2, temp2;
    begin2 = str2;
    end2 = str2;
    for (int c = 0; c < (strlen(str2) - 1); c++)
    {
        end2++;
    }
    for (int c = 0; c < strlen(str2) / 2; c++)
    {
        temp2 = *end2;
        *end2 = *begin2;
        *begin2 = temp2;
        begin2++;
        end2--;
    }
    //*******reversing a string************ END

    int carry = 0, str_i = 1;
    for (int i = 0; i < n1; i++)
    {
        int sum = ((*(str1 + i) - '0') + (*(str2 + i) - '0') + carry);

        if (sum > 9)
        {
            *(str + str_i) = ((sum - 10) + '0'); // if greater than 9
            str_i++;
        }
        else
        {
            *(str + str_i) = (sum + '0'); // if less than 9
            str_i++;
        }
        carry = sum / 10; // counting carry
    }

    for (int i = n1; i < n2; i++) // to add remaining of large number
    {
        int sum = ((*(str2 + i) - '0') + carry); // only add the large number

        if (sum > 9)
        {
            *(str + str_i) = ((sum - 10) + '0'); // if greater than 9
            str_i++;
        }
        else
        {
            *(str + str_i) = (sum + '0'); // if less than 9
            str_i++;
        }
        carry = sum / 10; // calculating carry
    }
    if (carry)
    {
        *(str + (str_i++)) = (carry + '0'); // adding remaining carry
    }

    // reverse string
    //*******reversing a string************ START
    char *begin, *end, temp;
    begin = str;
    end = str;
    for (int c = 0; c < (strlen(str) - 1); c++)
    {
        end++;
    }
    for (int c = 0; c < strlen(str) / 2; c++)
    {
        temp = *end;
        *end = *begin;
        *begin = temp;
        begin++;
        end--;
    }
    //*******reversing a string************ END
    *(str + strlen(str) - 1) = '\0';             // adding null character
    for (int i = 0; i < (strlen(str1) - 1); i++) // to remove unnecessary 0s
    {
        if (*str != '0')
        {
            break;
        }
        else
        {
            for (int j = i; j < (strlen(str1) - 1); j++)
            {
                *(str + j) = *(str + j + 1);
            }
            str = (char *)realloc(str, (strlen(str)) * sizeof(char));
            *(str + (strlen(str) - 1)) = '\0';
        }
    }
    free(str1); // freeing str1
    free(str2); // freeing str2
    return str;
}

//the following function returns a new string representing |m - n|
//complete the function definition:
// 1) you can assume both m and n represent valid non-negative integers
// 2) you do not need to free the dynamically allocate memory for the new string
char *diff(const char *m, const char *n) {
    char *str1 = (char *)calloc((strlen(m) + 1), sizeof(char)); // allocating space for str1
    strcpy(str1, m);                                            // copying the string to str1
    char *str2 = (char *)calloc((strlen(n) + 1), sizeof(char)); // allocating space for str2
    strcpy(str2, n);                                            // copying the string to str2

    if (gt(str2, str1)) // making sure str1 is greater than str2
    {
        char *temp = str1;
        str1 = str2;
        str2 = temp;
    }

    char *str = (char *)calloc((strlen(str1) + 2), sizeof(char)); // allocating space to store result

    *str = '0'; // adding null character

    int n1 = strlen(str1), n2 = strlen(str2);

    // Reverse strings
    //*******reversing a string************ START
    char *begin1, *end1, temp1;
    begin1 = str1;
    end1 = str1;
    for (int c = 0; c < (strlen(str1) - 1); c++)
    {
        end1++;
    }
    for (int c = 0; c < strlen(str1) / 2; c++)
    {
        temp1 = *end1;
        *end1 = *begin1;
        *begin1 = temp1;
        begin1++;
        end1--;
    }
    //*******reversing a string************ END
    //*******reversing a string************ START
    char *begin2, *end2, temp2;
    begin2 = str2;
    end2 = str2;
    for (int c = 0; c < (strlen(str2) - 1); c++)
    {
        end2++;
    }
    for (int c = 0; c < strlen(str2) / 2; c++)
    {
        temp2 = *end2;
        *end2 = *begin2;
        *begin2 = temp2;
        begin2++;
        end2--;
    }
    //*******reversing a string************ END

    int carry = 0, str_i = 1;
    for (int i = 0; i < n2; i++)
    {

        int sub = ((*(str1 + i) - '0') - (*(str2 + i) - '0') - carry);

        if (sub < 0)
        {
            sub = sub + 10; // making sub pos if it is neg
            carry = 1;      // carry will be 1
        }
        else
        {
            carry = 0; // if sum is pos
        }

        *(str + str_i) = (sub + '0'); // putting value in the string
        str_i++;
    }

    for (int i = n2; i < n1; i++) // to subtract remaining of large number
    {
        int sub = ((*(str1 + i) - '0') - carry);

        if (sub < 0)
        {
            sub = sub + 10; // making sub pos if it is neg
            carry = 1;      // carry will be 1
        }
        else
        {
            carry = 0; // if sum is pos
        }

        *(str + str_i) = (sub + '0'); // putting value in the string
        str_i++;
    }

    // reverse string
    //*******reversing a string************ START
    char *begin, *end, temp;
    begin = str;
    end = str;
    for (int c = 0; c < (strlen(str) - 1); c++)
    {
        end++;
    }
    for (int c = 0; c < strlen(str) / 2; c++)
    {
        temp = *end;
        *end = *begin;
        *begin = temp;
        begin++;
        end--;
    }
    //*******reversing a string************ END
    *(str + strlen(str) - 1) = '\0';             // adding null character
    for (int i = 0; i < (strlen(str1) - 1); i++) // to remove unnecessary 0s
    {
        if (*str != '0')
        {
            break;
        }
        else
        {
            for (int j = i; j < (strlen(str1) - 1); j++)
            {
                *(str + j) = *(str + j + 1);
            }
            str = (char *)realloc(str, (strlen(str)) * sizeof(char));
            *(str + (strlen(str) - 1)) = '\0';
        }
    }
    free(str1); // freeing str1
    free(str2); // freeing str2
    return str;
}
